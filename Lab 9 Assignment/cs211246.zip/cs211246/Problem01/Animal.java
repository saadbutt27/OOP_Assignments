package cs211246.Problem01;

public interface Animal {
    void eat();

    void travel();
}
