public class Bank {
    protected int balance;
    public int getBalance () {
        return 0;
    }
}
