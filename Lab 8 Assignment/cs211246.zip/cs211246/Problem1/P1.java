public class P1 {

    public static void main(String[] args) {
        // Problem 1
        System.out.println("*************************");
        System.out.println("Problem no. 1");
        Shapes obj = new Shapes();
        obj.area(2.5f, 3.8f);
        obj.area(2.5f);
        System.out.println("*************************\n");

    }
}
