package Problem1;

public class Manager extends Member {
    public String department;
}
