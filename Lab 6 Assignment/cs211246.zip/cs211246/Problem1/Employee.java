package Problem1;

public class Employee extends Member {
    public String specialization;
}
