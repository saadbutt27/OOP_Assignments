package Problem2;

public class Square extends Rectangle{
    Square(int s){
        length = s;
        bredth = s;
    }
}
